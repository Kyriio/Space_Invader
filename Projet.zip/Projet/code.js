//Vaisseau
var vaisseau  = new Image();                       // on déclare une nouvelle image nommée img
vaisseau.src  = "Sprite ISN/Vaisseau_3_coeurs.png";// charge l'image du dossier
var abscisse  = 30;                                // abscisse de départ du vaisseau
var ordonnee  = 536;                               // ordonee de départ du vaisseau
var direction = -1;                                // direction de défaut du vaisseau

//Soucoupe
var soucoupe          = new Image();              // nouvelle image pour la soucoupe
soucoupe.src          = "Sprite ISN/Soucoupe.png";//charge la soucoupe
var abscisseSoucoupe  = -60;                      //abscisse soucoupe
var ordonneeSoucoupe  = 30;                       // ordonnée soucoupe
var directionSoucoupe = 0;                        // direction défaut soucoupe
var soucoupeAffichee  = true;

//Chrono
var miliseconde = 0;          // crée une variable pour le chrono
var seconde     = 0;          // crée une variable pour les secondes
var minute      = 0;          // crée une variable pour les minutes
var start       = Date.now(); // crée une variable pour le start du chrono

//Bombe
var bombe         = new Image();             //déclare nouvelle image pour la bombe
bombe.src         = "Sprite ISN/Sbombe.png"; //charge l'image de la bombe
var abscisseBombe = abscisse + 22;           //abcisse de la bombe = abscisse du vaisseau
var ordonneeBombe = ordonnee + 20;           // ordonée de la bombe = ordonée du vaisseau
var deplacerBombe = 0;                       // variable pour déplacer la bombe quand touche enfoncé
var positionBombe = 0;                       // position de base de la bombe
var bombes        = 3;                       //variable pour le nombre de bombe

//Tir
var tir         = new Image();                 // Déclare une nouvelle image pour le tir
tir.src         = "Sprite ISN/Tir_simple.png"; // Charge l'image du tir
var abscisseTir = abscisse + 25;               // Même abscisse pour le Tir et le vaisseau
var ordonneeTir = ordonnee + 20;               // Même abscisse pour le Tir et le vaisseau
var positionTir = 0;                           // Position de bade du tir
var deplacerTir = 0;                           // Variable pour déplacer la tir quand touche enfoncé

//score
var score=0; // Crée une variable pour le score

//vie
var vie=3; // Crée une variable pour la vie

//son
var son_tir        = new Audio("Sons/Tir.mp3");                //crée une variable pour le son du tir
var son_bombe      = new Audio("Sons/Bombe.mp3");              //crée une variable pour le son de la bombe
var son_soucoupe   = new Audio("Sons/Soucoupe.mp3");           //crée une variable pour le son de la soucoupe
var son_perte_vie  = new Audio("Sons/Perte_vie.mp3");          //crée une variable pour la perte de vie
var son_soundtrack = new Audio ("Sons/soundtrack_reverb3.mp3");//crée une variable pour la soundtrack

//Invaders
var monstre3D=new Image(); // on déclare une nouvelle image nommée img
monstre3D.src="Sprite ISN/Monstre_3_droit.png"; // charge l'image du monstre à droite
var monstre3G=new Image(); // on déclare une nouvelle image nommée img
monstre3G.src="Sprite ISN/Monstre_3_gauche.png"; // charge l'image du monstre à gauche
var monstre3=new Image(); // on déclare une nouvelle image nommée img
monstre3.src="Sprite ISN/Monstre_3.png";	// charge l'image du monstre de base
var monstres=[monstre3,monstre3D,monstre3G]; // ici on a un tableau qui définis l'odre d'apparition des images pour l'animation
var animationInvaders=0; //la valeur de base pour la boucle de l'animation
var abscisseInvaders=0;// l'abscisse des invaders de base
var ordonneeInvaders=0;// l'ordonne des invaders de base
var directionInvaders=0;//On dit que l'invaders va vers la droite
var deplacementInvaders=10;//Le déplacement de l'invaders vaut 10 ( on utilise ça pour le déplacement plus loin)
var niveau1=[[1,1,1,1,1,1,1,1,1,1]];	// 1 ligne de 10 invaders pour le Niveau 1
var niveau2=[[1,1,1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1,1,1]];// 2 ligne de 10 invaders pour le Niveau 2
var niveau3=[[1,1,1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1,1,1]]; // 3 ligne de 10 invaders pour le Niveau 3
var niveau4=[[1,1,1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1,1,1]];// 4 ligne de 10 invaders pour le Niveau 4
var niveau5=[[1,0,0,0,1,1,0,0,0,1],[1,1,0,1,0,0,1,0,1,1],[1,0,1,1,0,0,1,1,0,1],[1,1,0,1,0,0,1,0,1,1],[1,0,0,0,1,1,0,0,0,1]]; //à partir du niveau 5 , plus de contrainte donc des petits dessins
var niveau6=[[1,1,1,1,1,1,1,1,1],[0,1,1,1,1,1,1,1,0],[0,0,1,1,1,1,1,0,0],[0,0,0,1,1,1,0,0,0],[0,0,0,0,1,0,0,0,0]];//à partir du niveau 5 , plus de contrainte donc des petits dessins
var niveau7=[[1,0,0,1,1,1,1,1,0,0,1],[0,1,1,0,0,0,0,0,1,1,0],[0,1,1,0,1,0,1,0,1,1,0],[0,1,1,0,0,0,0,0,1,1,0],[1,0,0,1,1,1,1,1,0,0,1]];//à partir du niveau 5 , plus de contrainte donc des petits dessins
var niveau8=[[1]];//le boss de fin des invaders
var niveauEnCours=6;//le Hacks
var nbInvaders=[0,10,20,30,40,26,25,28,1]; //On utilise le tableau regroupant le nombre d'invarders pour les colisions/le score
var nbCol=0; //nombre de colonnes des invaders
var nbLig=0;//nombre de Lignes des invaders

function demarrage () {
	var canvas=document.getElementById("canvas");//crée le canvas
	var ctx=canvas.getContext("2d");//définit le contexte du canvas
	canvas.width=600 ;//définit la largeur du canvas à 600
	canvas.height=600 ;//définit la longueur du canvas à 600
	dessiner();//appelle  la function dessiner
	var timer=setTimeout(changerPosition, 10); // dans 20ms, changerPosition se lancera une fois
	var timer=setTimeout(changerPositionInvaders,50); // dans 10ms, changerPosition se lancera une fois
	window.addEventListener("keydown",changerDirection);//abonne l'événement keydown à la fenêtre
	document.getElementById("temps").value; // récupère la valeur du temps
	//triche
	//soucoupeAffichee=true;
}


function afficheVaisseau(ctx) {
	with (ctx) {
		drawImage(vaisseau,0,0,64,64,abscisse,ordonnee,64,64);//dessine le vaisseau dans le canvas
	}
}

function afficheSoucoupe(ctx){
	with (ctx){
		drawImage(soucoupe,16,22,30,18,abscisseSoucoupe,ordonneeSoucoupe,30,20);//dessine la soucoupe dans le canvas
	}
	abscisseSoucoupe+=1;
}

function afficheBombe(ctx){
	with(ctx){
		drawImage(bombe,24,20,16,26,abscisseBombe,ordonneeBombe,20,30);//dessine la bombe dans le canvas
	}
}

function afficheTir(ctx){
	with (ctx){
		drawImage(tir,27,21,10,22,abscisseTir,ordonneeTir,12,22);
	}
}


function dessiner(){
	var canvas=document.getElementById("canvas");//récupére le canvas
	var ctx=canvas.getContext("2d");//definit le contexte du canvas
	canvas.width=canvas.width; // initialise le canvas et vide donc le ctx

	if (deplacerBombe==1){		// si bombe ==1 alors on affiche la bombe
		afficheBombe(ctx)
	}

	afficheTir(ctx); // fait apparaitre le tir sur le canvas

	afficheVaisseau(ctx);// fait apparaitre le vaisseau sur le canvas

	if((ordonneeInvaders>80) && (soucoupeAffichee)){ //si niveau vaut 3;5 ou 7 et si ordonnée des monstres est >80
			afficheSoucoupe(ctx); //alors on affiche la soucoupe
			son_soucoupe.play()//alors on joue le son de la soucoupe

	}
	if(abscisseSoucoupe>600){//si soucoupe hors canvas
		soucoupeAffichee=false;//alors collisionSoucoupe est vrai, la soucoupe ne s'affiche plus
		son_soucoupe.pause()//on stop le son
	}

	monHorloge(); // Appelle la fonction monHorloge
	gestionBombes();//appelle la fonction gestionBombes
	gestionVie(); // Appelle la fonction gestionVie
	test_son();//appelle la fonction test_son

	switch (niveauEnCours) { //ici on définis le niveau tout en affichant les invaders en fonction de l'animation / abscisse/ ordonee/ le tableau des invaders ( équivalent d'un if pour définir le niveauEnCours )
		case 1 :	invaders(ctx,abscisseInvaders,ordonneeInvaders,niveau1);
					break;
		case 2 :	invaders(ctx,abscisseInvaders,ordonneeInvaders,niveau2);
					break;
		case 3 :	invaders(ctx,abscisseInvaders,ordonneeInvaders,niveau3);
					break;
		case 4 :	invaders(ctx,abscisseInvaders,ordonneeInvaders,niveau4);
					break;
		case 5 :	invaders(ctx,abscisseInvaders,ordonneeInvaders,niveau5);
					break;
		case 6 :	invaders(ctx,abscisseInvaders,ordonneeInvaders,niveau6);
					break;
		case 7 :	invaders(ctx,abscisseInvaders,ordonneeInvaders,niveau7);
					break;
		case 8 :	invaders(ctx,abscisseInvaders,ordonneeInvaders,niveau8);
					break;
				}

//hitbox invaders
/*	with (ctx){
		beginPath()
		strokeStyle="red";
		for (var i=0;i<nbCol;i++){
			for (var j=0;j<nbLig;j++){
				rect(abscisseInvaders+i*30,ordonneeInvaders+j*20,30,20);
			}
		}
		closePath()
		stroke()
	}

//soucoupe
	if (soucoupeAffichee){
		with (ctx){
			beginPath()
			strokeStyle="red";
			rect(abscisseSoucoupe,ordonneeSoucoupe,30,20);
			closePath()
			stroke()
		}
	}

// tir
	with (ctx){
		beginPath()
		strokeStyle="red";
		rect(abscisseTir,ordonneeTir,12,22);
		closePath()
		stroke()
	}

//bombe
	with (ctx){
		beginPath()
		strokeStyle="red";
		rect(abscisseBombe,ordonneeBombe,20,30);
		closePath()
		stroke()
	}
	*/

	var animer=window.requestAnimationFrame(dessiner);// rafraîchit l'animation
}

function invader(ctx,x,y){
	with (ctx) {
		drawImage(monstres[animationInvaders],16,24,30,16,x,y,30,20); //ici on dessine le monstre en fonction du tableau de l'animation, avec ses caractéristiques,sa taille est définis ( 30 sur 20 )
	}

}

function invaders(ctx,x,y,niveau) {
	nbLig=niveau.length; //On prend la longueur des lignes
	for (var j=0;j<nbLig;j++) {
		nbCol=niveau[j].length; //On prend la longueur de des colonnes
		for (i=0;i<nbCol;i++) {
			if (niveau[j][i]==1) {
				invader(ctx,x+30*i,y+20*j); // dimension sprite 30*20 en prenant en compte le nombre d'invarders par ligne et Colonne
			}
		}

	}

}
//moi

function changerPositionInvaders(){
	animationInvaders=(animationInvaders+1)%3; //Ici,on prend le reste de la division euclidienne pour se placer dans le tableau ( 1 , 2 , 3 ... 1,2,3)

//deplacement
if(niveauEnCours<5){ //Pour les niveaux en dessous de 5
		if (directionInvaders==0){	 //si les invaders vont à droite
			abscisseInvaders+=4;	//on déplace l'abcisse des invaders de 4 pixels vers 0 (droite)
		}
		if (abscisseInvaders+30*(nbCol+1)>600){ //si l'abcisse des invaders ( jusqu'au dernier) est supérieur à 600
			ordonneeInvaders +=12; //on augmente l'ordonee des invaders de 12 pixels
			directionInvaders = 1  // la direction des invaders passe à 1 ( vers la gauche)
		}

	if (directionInvaders==1){ //si les invaders vont à gauche
		abscisseInvaders -=4; //on déplace l'abcisse des invaders de 4 pixels vers 1 (gauche)
	}

	if(abscisseInvaders <0) { // si l'abcisse des invaders (ici le premier) est inférieur à 0
		ordonneeInvaders+=12; // on augmente l'ordonne des invaders de 12
		directionInvaders = 0; // la direction des invaders passe à 0 ( vers la droite)
	}

}

	if(niveauEnCours >=5){//pour les niveaux supérieur ou égal  à 5
		if (directionInvaders==0){ // si les invaders vont à droite
			abscisseInvaders+=7; ////on déplace l'abcisse des invaders de 7 pixels vers 0 (droite)
			}

		if (abscisseInvaders+30*(nbCol+1)>600){ //si l'abscisse des invaders jusqu'au bout est supérieur à 600
			ordonneeInvaders +=12;//on augmente l'ordonee des invaders de 12 pixels
			directionInvaders = 1 // la direction des invaders passe à 1 ( vers la gauche)
			}
		if (directionInvaders==1){ //si les invaders vont à gauche
			abscisseInvaders-=7; //on déplace l'abcisse des invaders de 7 pixels vers 1 (gauche)
			}
		if(abscisseInvaders <0) { // si l'abscisse des invaders est inférieur à 0
			ordonneeInvaders+=12;//on augmente l'ordonee des invaders de 12 pixels
			directionInvaders = 0;// la direction des invaders passe à 0 ( vers la droite)
			}

}


	if (niveauEnCours == 8){ // pour le niveau 8
		if (directionInvaders==0){ //si la direction des invaders est à 0 ( vers la droite)
			abscisseInvaders+= Math.floor(Math.random()*40); // on déplace l'invaders grâce au reste d'un nombre aléatoire entre 0 et 40 ( vers la droite)
			}

		if (abscisseInvaders+30*(nbCol+1)>Math.floor(Math.random()*200)+Math.floor(Math.random()*400)){ // si l'abcisse du dernier invaders est supérieur à un nombre entre 0 et 200 + un nombre entre 0 et 400 (max 600) mini (0)
			ordonneeInvaders += Math.floor(Math.random()*30); // on augmente l'ordonnee de l'invaders d'un nombre aléatoire entre 0 et 30
			directionInvaders = 1
			}

		if (directionInvaders==1){ //si la direction des invaders est à 1 ( vers la gauche)
			abscisseInvaders -= Math.floor(Math.random()*40); // on déplace l'invaders grâce au reste d'un nombre aléatoire entre 0 et 40 ( vers la gauche)
			}

		if(abscisseInvaders < Math.floor(Math.random()*600)){ // si l'abcisse des invaders est inférieur à un nombre entre 0 et 600
			ordonneeInvaders += Math.floor(Math.random()*30); // on augmente l'ordonnee de l'invaders d'un nombre aléatoire entre 0 et 30
			directionInvaders = 0; // la direction des invaders passe à 0 ( vers la droite)
			}
	}

	if(niveauEnCours>8){ //Si le niveau est Supérieur à 8 ( fin )
		RedirectionJavascript(); // Appelle la fonction redirectionJavascript
	}
	if (niveauEnCours>0){
		window.localStorage.setItem("score", score);// les données stockées dans le localStorage n'ont pas de délai d'expiration donc on stock ici le score
		window.localStorage.setItem("vie", vie-1); // les données stockées dans le localStorage n'ont pas de délai d'expiration donc on stock la vie
		window.localStorage.setItem("temps", minute + ":" + seconde); // les données stockées dans le localStorage n'ont pas de délai d'expiration donc on stock le temps
	}

	var timer=setTimeout(changerPositionInvaders,100); // dans 100ms, changerPosition se lancera une fois
}


function RedirectionJavascript(){ // Fonction pour rediriger le joueur
  document.location.href="page_fin.html"; // envoie le joueur a la page de fin
}

function Viess(){

  if (vie>0){ // si vie>0
  	document.getElementById("spritesVies").src="Sprite ISN/"+vie+"_coeurs.png"; // Charge le sprite correspondant au nombres de vies
  }
  else {
		RedirectionJavascript(); // redirection page de fin
  }
}

function gestionVie(){

	if(vie>0){
		vaisseau.src="Sprite ISN/Vaisseau_"+vie+"_coeurs.png";//affiche le sprite de vaisseau en fonction du nb de vie
	}

	if(ordonneeInvaders+20*(nbLig+1)>ordonnee){ // si l'ordonne de la première ligne d'invaders>ordonnee du vaisseau ( 20 pour la hauteur du sprite invaders)
		// Remet les entités a leurs positions de départ
		ordonneeInvaders=0;
		abscisseInvaders=20;
		ordonnee=536;
		abscisse=30;
		vie-=1; // perte d'une vie
		Viess();// Appelle la fonction Viess
		son_perte_vie.play();//appelle la fonction son_perte_vie
		collisionSoucoupe=true;
	}
}

/*
direction == 0 -> Va à droite
direction == 1 -> Va à gauche
direction == 2 -> Va en haut
direction == 3 -> Va en bas
*/
function changerDirection(event){
	switch (event.keyCode){//verifie quelle touche du clavier est est enfoncé
		case 39 : direction = 0 // si touche fléche droit direction vaut 0
			break;
		case 37 : direction = 1 // si touche flèche gauche direction vaut 1
			break;
		case 38 : direction = 2 // si touche flèche haut direction vaut 2
			break;
		case 40 : direction = 3 // si touche flèche bas direction faut 3
			break;
		case 70 : if (bombes>0) {deplacerBombe =1; bombes--;} // si touche f  et que bombe est supérieur à 0 depalcerBombe vaut 1
			break;
		case 68 : deplacerTir=1
		 					son_tir.play();// définis le cas 1 pour deplacerTir
			break;
	default : direction = -1;
	}
}


function changerPosition(){
	switch (direction) { //vérifie la variable direction
		case 0 : 	//si direction vaut 0 et que abscisse < 550 on augmente l'abscisse de 2
			if (abscisse<550) {
				abscisse +=2;
			}
		break;

		case 1 :   //si direction vaut 1 et que abscisse > 0 on diminue l'abscisse de 2
			if (abscisse>0) {
				abscisse -=2;
			}
		break;

		case 2 :  //si direction vaut 2 et que ordonée > 20 on diminue l'abscisse de 1
			if (ordonnee>20) {
				ordonnee-=2;
			}
		break;

		case 3 :  //si direction vaut 3 et que ordonée < 550 on augmente l'abscisse de 1
			if (ordonnee<550) {
				ordonnee+=2;
			}
		break;
	}

	if (deplacerTir!=1) { // si on  ne tire pas
			abscisseTir=abscisse + 25; // même abscisse pour le vaisseau et le tir
			ordonneeTir=ordonnee + 20; // même ordonnee pour le vaisseau et le tir
	}

	if (deplacerBombe!=1) { //si deplacerBombe est différent de 1
			abscisseBombe=abscisse + 22; //alors l'abscisse et l'ordonnée de la bombe = celle du vaisseau
			ordonneeBombe=ordonnee + 20;
	}

	switch(deplacerBombe){	//vérfie la variable deplacerBombe
		case 1 : ordonneeBombe-=2 //si déplacerBombe vaut 1 ordonneeBombe = ordonneeBombe - 2 (bombe va monter)
			if(ordonneeBombe<0) { //si ordonneBombe<0
				deplacerBombe=0; //alors deplacerBombe =0
			}
		break;

	}

	switch(deplacerTir){
	 case 1 : ordonneeTir-=2 // dans le cas 1 diminue l'ordonnee de 6
	 	if (ordonneeTir<0)	{ //si l'ordonnée du Tir<0
	 		deplacerTir=0;     // deplacer Tir ne se lance pas
	 	}
	 	break;
	}

	if(deplacerTir==1){ // si on tire
		ordonneeTir = ordonneeTir-2; // diminue l'ordonnee de 2 en 2

		switch (niveauEnCours) {
				case 1 :  testerCollisionTir(niveau1); // teste la collision du tir pour le niveau 1
					break;
				case 2 :	testerCollisionTir(niveau2); // teste la collision du tir pour le niveau 2
					break;
				case 3 :	testerCollisionTir(niveau3); // teste la collision du tir pour le niveau 3
					break;
				case 4 :	testerCollisionTir(niveau4); // teste la collision du tir pour le niveau 4
					break;
				case 5 :	testerCollisionTir(niveau5); // teste la collision du tir pour le niveau 5
					break;
				case 6 :	testerCollisionTir(niveau6); // teste la collision du tir pour le niveau 6
					break;
				case 7 :	testerCollisionTir(niveau7); // teste la collision du tir pour le niveau 7
					break;
				case 8 :	testerCollisionTir(niveau8); // teste la collision du tir pour le niveau 8
					break;
		}

}


	// si bombe en mvt en cours
	if(deplacerBombe==1){
		ordonneeBombe = ordonneeBombe-2

		switch (niveauEnCours) { //teste la variable niveau en cours
			//teste la collision pour tous les niveaux
				case 1 :  testerCollisionBombe(niveau1);
					break;
				case 2 :  testerCollisionBombe(niveau2);
					break;
				case 3 :  testerCollisionBombe(niveau3);
					break;
				case 4 :  testerCollisionBombe(niveau4);
					break;
				case 5 :  testerCollisionBombe(niveau5);
					break;
				case 6 :  testerCollisionBombe(niveau6);
					break;
				case 7 :  testerCollisionBombe(niveau7);
					break;
				case 8 :  testerCollisionBombe(niveau8);
		}

		if (ordonneeBombe<0) { //si ordonnée de la bombe ets inférieur à 0
			deplacerBombe=0; //alors déplacer bombe vaut 0
			abscisseBombe=abscisse + 22; //abscisse de la bombe vaut celle du vaisseau
			ordonneeBombe=ordonnee + 20; //ordonee de la bombe vaut celle du vaisseau

		}
	}
	var timer=setTimeout(changerPosition, 10);
}



function testerCollisionBombe(niveau){
	nbLig=niveau.length;
	collision=false;//variable booleene qui vaux false, faux, renvoie 0
	colx=0;
	coly=0;
	for (var i=0;i<nbLig;i++) {//pour i<nbLig on ajoute +1 à i
		nbCol=niveau[i].length; //nbCol = la longueur du niveau de i
		for (var j=0;j<nbCol;j++) {//pour j<nbCol on ajoute +1 à j
			if ((abscisseBombe>=abscisseInvaders+j*30) && (abscisseBombe<=abscisseInvaders+(j+1)*30)
				&& (ordonneeBombe>=ordonneeInvaders+i*20-20) && (ordonneeBombe<=ordonneeInvaders+i*20) && (niveau[i][j]!=0)) {
					colx=j;
					coly=i;
					collision=true;//variable booleene qui vaux true, vrai, renvoie 1
					i=nbLig;
					j=nbCol;
					deplacerBombe=0;
			}
		}
	}

	if  ((soucoupeAffichee) && (abscisseBombe>abscisseSoucoupe) && (abscisseBombe<abscisseSoucoupe+30) && (ordonneeBombe>ordonneeSoucoupe) && (ordonneeBombe<ordonneeSoucoupe+20)) {
		soucoupeAffichee=false;
		bombes++
		deplacerTir=0;
		abscisseSoucoupe =-60;
	}


	if ((collision)&&(niveau[coly][colx]!=0)) { //si collision est vrai et que coly et colx est différent de 0

		switch (niveauEnCours) {
			case 1 :	nbInvaders[niveauEnCours]=nbInvaders[niveauEnCours]-compte_invaders_dans_ligne(niveau1[coly]); //nb d'invaders du niveau = nb invders du niveau - nombre invaders qu'il reste sur la ligne
								niveau3[coly]=[0,0,0,0,0,0,0,0,0,0];//detruit la ligne touché
								son_bombe.play();//joue le son de la bombe
				break;
			case 2 :	nbInvaders[niveauEnCours]=nbInvaders[niveauEnCours]-compte_invaders_dans_ligne(niveau2[coly]); //nb d'invaders du niveau = nb invders du niveau - nombre invaders qu'il reste sur la ligne
									niveau3[coly]=[0,0,0,0,0,0,0,0,0,0];//detruit la ligne touché
									son_bombe.play();//joue le son de la bombe
				break;
			case 3 :	nbInvaders[niveauEnCours]=nbInvaders[niveauEnCours]-compte_invaders_dans_ligne(niveau3[coly]); //nb d'invaders du niveau = nb invders du niveau - nombre invaders qu'il reste sur la ligne
								niveau3[coly]=[0,0,0,0,0,0,0,0,0,0];//detruit la ligne touché
								son_bombe.play();//joue le son de la bombe
				break;
			case 4 :	nbInvaders[niveauEnCours]=nbInvaders[niveauEnCours]-compte_invaders_dans_ligne(niveau4[coly]);//nb d'invaders du niveau = nb invders du niveau - nombre invaders qu'il reste sur la ligne
								niveau4[coly]=[0,0,0,0,0,0,0,0,0,0];//detruit la ligne touché
								son_bombe.play();//joue le son de la bombe
				break;
			case 5 :	nbInvaders[niveauEnCours]=nbInvaders[niveauEnCours]-compte_invaders_dans_ligne(niveau5[coly]);//nb d'invaders du niveau = nb invders du niveau - nombre invaders qu'il reste sur la ligne
								niveau5[coly]=[0,0,0,0,0,0,0,0,0,0];//detruit la ligne touché
								son_bombe.play();//joue le son de la bombe
				break;
			case 6 :  nbInvaders[niveauEnCours]=nbInvaders[niveauEnCours]-compte_invaders_dans_ligne(niveau6[coly]);//nb d'invaders du niveau = nb invders du niveau - nombre invaders qu'il reste sur la ligne
								niveau6[coly]=[0,0,0,0,0,0,0,0,0,0];//detruit la ligne touché
								son_bombe.play();//joue le son de la bombe
				break;
			case 7 :	nbInvaders[niveauEnCours]=nbInvaders[niveauEnCours]-compte_invaders_dans_ligne(niveau7[coly]);//nb d'invaders du niveau = nb invders du niveau - nombre invaders qu'il reste sur la ligne
								niveau7[coly]=[0,0,0,0,0,0,0,0,0,0];//detruit la ligne touché
								son_bombe.play();//joue le son de la bombe
				break;
			case 8 :	nbInvaders[niveauEnCours]=nbInvaders[niveauEnCours]-compte_invaders_dans_ligne(niveau8[coly]);//nb d'invaders du niveau = nb invders du niveau - nombre invaders qu'il reste sur la ligne
								niveau8[coly]=[0,0,0,0,0,0,0,0,0,0];//detruit la ligne touché
								son_bombe.play();//joue le son de la bombe
				break;
		}

		Scores(); //lance la fonction score
		if (nbInvaders[niveauEnCours]==0) { //si le nb invaders du niveau est égal à 0
			niveauEnCours++; //alors on monte de niveau
		if ((niveauEnCours==3)||(niveauEnCours==5)||(niveauEnCours==7)){
				soucoupeAffichee=true;
			}
			else {
				soucoupeAffichee=false;
			}
			abscisseInvaders=0;//on remet les invaders en haut du canavs
			ordonneeInvaders=0;
			abscisse=30; //et le vaisseau en bas à gauche
			ordonnee=536;
			abscisseSoucoupe =-60;

			if(niveauEnCours==7){// si le niveau en cours est égale à 7
				bombes++ //on donne une bombe
			}

			if(niveauEnCours==5){//si il est égale à 5
				vie++ //on donne une vie
			}

			if(niveauEnCours>8){
				vie++;
				redirectionJavascript();
			}
		}
	}
}

function compte_invaders_dans_ligne(ligne){//cette fonction va compter le nombre d'invaders sur la ligne
	var nb=0 //crée une variable nb
	for (var i=0;i<ligne.length;i++){//pour i < longueur de la ligne on ajoute +1 à i
		if (ligne[i]==1) { //si monstres sur la ligne
			nb++ // alors on donne =1 à la variable
		}
	}
	return nb //la fonction retourne la variable nb
}


function testerCollisionTir(niveau){
	nbLig=niveau.length;
	collision=false; //variable booleene qui renvoie un faux
	colx=0;
	coly=0;
	for (var i=0;i<nbLig;i++) { // pour i<nbLig on ajoute +1 à i
		nbCol=niveau[i].length; // nbCol = la longueur du niveau de i
		for (var j=0;j<nbCol;j++) { //pour j<nbCol on ajoute +1 à j
			if ((abscisseTir>=abscisseInvaders+j*30) && (abscisseTir<=abscisseInvaders+(j+1)*30)
				&& (ordonneeTir>=ordonneeInvaders+i*20-20) && (ordonneeTir<=ordonneeInvaders+i*20) && (niveau[i][j]!=0)) {
					colx=i; // on définit colX comme i
					coly=j; // on définit colY comme j
					collision=true; // variable booleene qui renvoie un vrai
					i=nbLig; // J = nombre de lignes
					j=nbCol; // i = nombre de colones
					deplacerTir=0; // la touche de tir n'est pas enclenché
			}
		}
	}

	// collision avec la soucoupe
	// voici la ligne de code qui affiche le rctangle dans lequel est la soucoupe rect(abscisseSoucoupe,ordonneeSoucoupe,30,20);
	// si ((abscisseTir>abscisseSoucoupe) et que (abscisseTir<abscisseSoucoupe+30) et que (ordonneeTir>ordonneeSoucoupe) et que (ordonneeTir<ordonneeSoucoupe+20)) alors {
		// on a touché la soucoupe -> elle disparait
		// le tir est stoppé
		// le nbre de bombe(s) disponible(s) augmente
	if  ((soucoupeAffichee)&&(abscisseTir>abscisseSoucoupe) && (abscisseTir<abscisseSoucoupe+30) && (ordonneeTir>ordonneeSoucoupe) && (ordonneeTir<ordonneeSoucoupe+20)) {
		soucoupeAffichee=false;
		bombes++
		deplacerTir=0;
		abscisseSoucoupe = -60;
	}

	// tir simple
	if ((collision)&&(niveau[colx][coly]!=0)) { // Collision est vraie et que les colX et colY sont différents de 0
 // détruit linvaders aux coordonnées en colx et colY pour chaque niveaux
		switch (niveauEnCours) {
			case 1 :	niveau1[colx][coly]=0;
				break;
			case 2 :	niveau2[colx][coly]=0;
				break;
			case 3 :	niveau3[colx][coly]=0;
				break;
			case 4 :	niveau4[colx][coly]=0;
				break;
			case 5 :	niveau5[colx][coly]=0;
				break;
			case 6 :	niveau6[colx][coly]=0;
				break;
			case 7 :	niveau7[colx][coly]=0;
				break;
			case 8 :	niveau8[colx][coly]=0;
				break;
		}
		Scores(); // Appelle la fonction Scores
		nbInvaders[niveauEnCours]--;
		if (nbInvaders[niveauEnCours]==0) { // si il n'y a plus d'invaders
			niveauEnCours++; // passe le niveau
		//soucoupe
			if ((niveauEnCours==3)||(niveauEnCours==5)||(niveauEnCours==7)){
				soucoupeAffichee=true;
			}
			else {
				soucoupeAffichee=false;
			}
			// remet les entités a leurs positions de départ
			abscisseInvaders=0;
			ordonneeInvaders=0;
			abscisse=30;
			ordonnee=536;
			abscisseSoucoupe =-60;

			if(niveauEnCours==7){ // arrivé au septième niveau
				bombes++ // gagne une bombe
			}
			if(niveauEnCours==5){ // arrivé au niveau 5
				vie++ // gagne une vie
			}
			if(niveauEnCours>8){
				vie++;
				redirectionJavascript();
			}
		}
	}
}

function monHorloge() {
    miliseconde= Date.now()-start; //stocke la différence entre l'heure on ou a commencé et l'heure ou l'on est en ms
		seconde=Math.floor((miliseconde/1000)%60);// transformation miliseconde en seconde ; %60 reste de la division minute=Math.floor((miliseconde/1000/60)%60);
		if (seconde<10) {
			seconde="0"+seconde; // rajoute un 0 à gauche du chiffre
		}
		minute=Math.floor((miliseconde/1000/60)%60); // transformation miliseconde en minute ; %60 reste de la division	 // transformation miliseconde en minute ; %60 reste de la division
    if (minute<10){
      minute="0"+minute; // rajoute un 0 à gauche du chiffre
    }
    var texte= minute + ":" + seconde; // créer la chaine de caractère a afficher

    document.getElementById("temps").innerHTML = texte; // renvoie le texte dans l'élement HTML
}

function gestionBombes(){

	document.getElementById("Bombe").innerHTML="<img src=\"Sprite ISN/bombe_"+bombes+".png\"/>";//on remplace l'image à droite de la page selon la valeur de la variable bombe
}


function Scores(){

		if(nbInvaders[niveauEnCours]!=nbInvaders&&niveauEnCours!=8){ // si nombre d'invader!=nombre d'invaders de base et niveau différent de 8
				score+=15;
				document.getElementById("score").innerHTML="<p>"+score+"</p>";				// écrire le score dans l'élément HTML
				//document.getElementById("Score").innerHTML="<p> Votre score"+score+"/3010</p>";
		}

		if(nbInvaders[niveauEnCours]!=nbInvaders&&niveauEnCours==8){ //si nombre d'invader!=nombre d'invaders de base et niveau est 8
			score+=100;
			document.getElementById("score").innerHTML="<p>"+score+"</p>"; // écrire le score dans l'élément HTML
		}
}




function test_son(){

	if(niveauEnCours>0){
		son_soundtrack.play();
	}
}


 function recupVar(){
	 document.getElementById("Score").innerHTML =  "Score : "+ window.localStorage.getItem("score") +" / 3010 ";//On dit qu'on peut écrire dans mon ID : Score le score
	 document.getElementById("Vie").innerHTML =  "Vie : "+ window.localStorage.getItem("vie") +" / 4 ";//on dit qu'on peut écrire dans mon id Vie : la vie
	 document.getElementById("Temps").innerHTML =  "Temps : "+ window.localStorage.getItem("temps");//on dit qu'on peut écrire dans mon id Temps: le temp
}

window.addEventListener("load", demarrage);
